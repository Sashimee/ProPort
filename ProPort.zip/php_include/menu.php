<nav>
    <section id="sideBarWrapper">
        <div id="bigBar">
            <div id="buttonBar"><i class="fas fa-bars"></i></div>
        </div>
    </section>
    <section id="mainMenu">
        <div class="logo">
            <section id="symbolBorder">
                <span id="symbol">#</span>
            </section>
            <span id="name">Sashimee</span>
        </div>
        <ul>
            <li>
                <a class="mainMenuLinks" href="/index.php"><span class="anchorGradient">Home</span></a>
            </li>
            <li>
                <a class="mainMenuLinks" href="/projects/projects.php"><span class="anchorGradient">Projects</span></a>
            </li>
            <li>
                <a class="mainMenuLinks" href="/contact/contact.php"><span class="anchorGradient">Contact</span></a>
            </li>
        </ul>
    </section>
</nav>