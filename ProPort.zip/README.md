# ProPort
Portfolio
---v0.7---
- New project added
- Learned how to sanitize inputs with php
- Added a new contact possibility
- Fixing some screen issues on lower resolutions

--- v0.6 ---
- Migrating to php
- Setting up lamp stack
- Getting domain
- configuring SSL certificates for domain & subdomains

--- v0.5 ---
- New contact section
- cleaning "under construction" icons

--- v0.4 ---
- Cleaning README.md
- currently online on sashimee.com
- changing the "versioning syntax"
- renamed blog to projects
- integrated an example of an ajax call
- Home content redesign

--- v0.3 ---
- box design
- some images
- bug fixing
- menu transparency
- new repo because of it

--- v0.2 ---

- responsive menu design for >1200px
- bug hunting
- changing colours
- redo jQuery and json parts

--- v0.1 ---

- First Sketch
- Defining Scope
- Design choices : 
    - Fonts
    - Colours
- Coding imports + deciding on comment strategy
- First SASS style + generating CSS + Linking
- Font var definition
- Discovered SASS import is even easier than I thought
- Tip to myself : Take a fun approach, accept frustration
- separating all the css by elements, etc...
- Firt menu design steps, I want a logo ! => Free logo creator sites are bad, desiginng one in CSS
- Learned about font gradient
- learned to convert old webkit code into usable code
- migrating this list to this document. Before, it was handwritten
- SASS compiler doesn't compile the target sass import as intended ... Going to use a tool Igor told me
- Styling/developing the menu
- Layout is getting better / designing the buttons/anchors !!! 
- Getting bored after 4H working on this part
- display: none'd the menu ^^ starting my nice design sidebar
- design is doing good; function to open/close the menu so first add of javascript to the page
- feels like because of the number of classes/different/languages there seem to be naming issues not yet big enought to retake the whole naming synthax
- posting blured screenshot on Facebook and linked in
